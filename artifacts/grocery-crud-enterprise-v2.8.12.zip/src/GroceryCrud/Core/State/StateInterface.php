<?php

namespace GroceryCrud\Core\State;


interface StateInterface
{
    public function render();
}